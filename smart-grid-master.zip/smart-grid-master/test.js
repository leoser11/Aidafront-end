var root = __dirname;
var smartgrid = require(root + '/index.js');
smartgrid();